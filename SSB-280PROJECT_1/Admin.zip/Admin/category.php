<!-- Header -->
<?php include 'includes/header.php'; ?>
<!-- /.header -->


  <!-- Navbar -->
  <?php include 'includes/topbar.php'; ?>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <?php include 'includes/sidebar.php'; ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Manage Category</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
              <li class="breadcrumb-item"><a href="category.php">Category</a></li>
              <li class="breadcrumb-item active">Manage Category</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">

      <div class="container-fluid">
            <div class="row">
                <!-- left col -->
                    <div class="col-lg-5 col-md-6">
                        <!-- Add/Update category form starts -->

                        <?php 
                          if(isset($_GET['edit_id'])){ 

                            $editId           = $_GET['edit_id'];
                            $query            = "SELECT * FROM category WHERE id = '$editId'";
                            $result           = mysqli_query($conn, $query);

                            $data = mysqli_fetch_assoc($result);

                            if($data==null){
                               header("Location: category.php");
                               exit();
                            }
                            
                            extract($data);
                        ?>
                          <div class="card card-info">
                            <div class="card-header">
                              <h3 class="card-title">
                                Update Category
                              </h3>

                              <div class="card-tools">
                                <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                                  <i class="fas fa-minus"></i>
                                </button>
                              </div>
                            </div>
                            <div class="card-body p-3">
                                <form action="" method="post">
                                    <div class="form-group">
                                        <label for="cat-name">Name</label>
                                        <input type="text" name="name" id="cat-name" class="form-control" value="<?=$name;?>" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="cat-desc">Description</label>
                                        <textarea name="description" id="cat-desc" class="form-control"><?=$description;?></textarea>
                                    </div>
                                    <div class="form-group">
                                        <label for="parentCat">Parent Category</label>
                                        <select name="parentCat" id="parentCat" class="form-control select2bs4">
                                        <option value="0">--Select Parent Category if has any--</option>
                                              <?php 
                                                  $updateParentCategoryQuery  = "SELECT id as 'updateParentCatId', name AS 'updateParentCatName' FROM category WHERE id!='$editId' AND parent=0 ORDER BY name ASC";

                                                  $updateParentCategoryResult = mysqli_query($conn, 
                                                  $updateParentCategoryQuery);
                                                  
                                                  while($row = mysqli_fetch_assoc($updateParentCategoryResult)){
                                                    extract($row);
                                              ?>
                                                  <option value="<?=$updateParentCatId?>" <?php if($updateParentCatId==$parent){ echo 'selected'; } ?>><?=$updateParentCatName;?></option>
                                              <?php } ?>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="cat-status">Status</label>
                                        <select name="status" id="cat-status" class="form-control">
                                            <option value="">--Select Status--</option>
                                              <option value="1" <?php if($status==1){ echo "selected"; } ?> >Active</option>
                                              <option value="0" <?php if($status==0){ echo "selected"; } ?> >In-active</option>
                                        </select>
                                    </div>
                                    <input type="hidden" name="editId" value="<?=$id;?>">
                                    <div class="form-group">
                                        <button name="update" class="btn btn-info btn-block text-bold">Update&ensp;</button>
                                    </div>
                                </form>
                            </div>
                            <!-- /.card-body -->
                          </div>
                        <?php } else { ?>
                          <div class="card card-primary">
                            <div class="card-header">
                              <h3 class="card-title">
                                Add New Category
                              </h3>

                              <div class="card-tools">
                                <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                                  <i class="fas fa-minus"></i>
                                </button>
                              </div>
                            </div>
                            <div class="card-body p-3">
                                <form action="" method="post">
                                    <div class="form-group">
                                        <label for="cat-name">Name</label>
                                        <input type="text" name="name" id="cat-name" class="form-control" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="cat-desc">Description</label>
                                        <textarea name="description" id="cat-desc" class="form-control"></textarea>
                                    </div>
                                    <div class="form-group">
                                        <label for="parentCat">Parent Category</label>
                                        <select name="parentCat" id="parentCat" class="form-control select2bs4">
                                            <option value="0" selected>--Select Parent Category if has any--</option>
                                              <?php 
                                                  $addParentCategoryQuery  = "SELECT id as 'addParentCatId', name AS 'addParentCatName' FROM category WHERE parent=0 ORDER BY name ASC";

                                                  $addParentCategoryResult = mysqli_query($conn, 
                                                  $addParentCategoryQuery);
                                                  
                                                  while($row = mysqli_fetch_assoc($addParentCategoryResult)){
                                                    extract($row);
                                              ?>
                                                  <option value="<?=$addParentCatId?>"><?=$addParentCatName;?></option>
                                              <?php } ?>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="cat-status">Status</label>
                                        <select name="status" id="cat-status" class="form-control">
                                            <option value="">--Select Status--</option>
                                              <option value="1">Active</option>
                                              <option value="0">In-active</option>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <button name="create" class="btn btn-primary btn-block text-bold">Submit</button>
                                    </div>
                                </form>
                            </div>
                            <!-- /.card-body -->
                          </div>
                        <?php } ?>

                        <!-- Add/Update category form ends -->
                    </div>
                <!-- /.left col -->

                <!-- right col -->
                    <div class="col-lg-7 col-md-6">
                        <!-- All category starts -->

                          <div class="card card-secondary">
                            <div class="card-header">
                              <h3 class="card-title">All Categories</h3>

                              <div class="card-tools">
                                <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                                  <i class="fas fa-minus"></i>
                                </button>
                              </div>
                            </div>
                            <div class="card-body p-0">
                              <table class="table table-striped table-bordered projects">
                                  <thead>
                                      <tr>
                                          <th style="width: 5%">
                                              #SL
                                          </th>
                                          <th style="width: 45%">
                                              Name
                                          </th>
                                          <th style="width: 15%">
                                              Parent
                                          </th>
                                          <th style="width: 15%">
                                              Status
                                          </th>
                                          <th style="width: 20%">
                                              Action
                                          </th>
                                      </tr>
                                  </thead>
                                  <tbody>

                                  <?php 
                                      $query  = "SELECT * FROM category";
                                      $result = mysqli_query($conn, $query);
                                      $sl     = 1;
                                      $statusBadge   = array('danger', 'success');
                                      $statusMessage = array('In-active', 'Active');

                                      while($row = mysqli_fetch_assoc($result)){
                                      
                                      extract($row);
                                      
                                  ?>
                                      <tr>
                                          <td>
                                              <span class="badge badge-secondary"><?=$sl;?></span>
                                          </td>
                                          <td style="font-size: 13pt;">
                                              <?=$name;?>
                                          </td>
                                          <td>
                                              <span class="badge badge-<?=$statusBadge[$status];?>"><?=$statusMessage[$status];?></span>
                                          </td>
                                          <td>
                                              <?php
                                                if($parent == 0){ ?>
                                                <span class="badge badge-primary">Primary</span>
                                              <?php } else{ 
                                                
                                                $getParentCategoryQuery = "SELECT name AS 'parentName' FROM category WHERE id = '$parent'";

                                                $parentCategoryName = mysqli_fetch_assoc(mysqli_query($conn, $getParentCategoryQuery))['parentName'];
                                                
                                              ?>
                                                <span class="badge badge-info"><?=$parentCategoryName;?></span>
                                              <?php } ?>
                                          </td>
                                          <td class="project-actions">
                                              <a class="btn btn-info btn-sm mb-1" href="category.php?edit_id=<?=$id;?>">
                                                  <i class="fas fa-pencil-alt">
                                                  </i>
                                              </a>
                                              <button class="btn btn-danger btn-sm mb-1" data-toggle="modal" data-target="#deleteCategory_<?=$id;?>">
                                                  <i class="fas fa-trash">
                                                  </i>
                                              </button>
                                          </td>
                                      </tr>
                                        <!-- Delete Modal -->
                                    <div class="modal fade" id="deleteCategory_<?=$id;?>" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                          <div class="modal-dialog modal-dialog-centered">
                                            <div class="modal-content">
                                              <div class="modal-header">
                                                <h5 class="modal-title text-center w-100" id="staticBackdropLabel">Are you sure?</h5>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                  <span aria-hidden="true">&times;</span>
                                                </button>
                                              </div>
                                              <div class="modal-body text-center">
                                                Do you want to delete <b><?=$name;?> </b>,category? <br> You won't be able revert this choice!
                                              </div>
                                              <div class="modal-footer">
                                                <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
                                                <a href="category.php?delete=<?=$id;?>" class="btn btn-success">Okay</a>
                                              </div>
                                            </div>
                                          </div>
                                        </div>
                                      <?php $sl++; } ?>
                                  </tbody>
                              </table>
                            </div>
                            <!-- /.card-body -->
                          </div>
                        
                        <!-- All category ends -->

                        
                        <?php

                          $operationMode = false;

                            if(isset($_POST['create'])){
                              extract($_POST);
                              $formErrors = array();

                              if(empty(trim($name))){
                                $formErrors[]="Empty name!";
                              }
                              else if(mb_strlen($name)<2){
                                $formErrors[]="Name is too short!";
                              }
                              else if(mb_strlen($name)>150){
                                $formErrors[]="Name is too long!";
                              }

                              if(!empty($formErrors)){
                                  $_SESSION['toastr']['message']    = $formErrors;
                                  $_SESSION['toastr']['alertType']  = "danger";
                              }
                              else{
                                  $query  = "INSERT INTO category(name, description, parent, status) 
                                                        VALUES('$name', '$description', '$parentCat', '$status')";

                                  $result = mysqli_query($conn, $query);
                                  
                                  $operationMode = "add";
                              }

                            }
                            else if(isset($_POST['update'])){
                              extract($_POST);

                              $formErrors = array();

                              if(empty(trim($name))){
                                $formErrors[]="Empty name!";
                              }
                              else if(mb_strlen($name)<2){
                                $formErrors[]="Name is too short!";
                              }
                              else if(mb_strlen($name)>150){
                                $formErrors[]="Name is too long!";
                              }

                              if(!empty($formErrors)){
                                $_SESSION['toastr']['message']    = $formErrors;
                                $_SESSION['toastr']['alertType']  = "danger";
                              }
                              else{

                                $query  = "UPDATE category SET name='$name', description='$description', parent ='$parentCat', status='$status' WHERE id='$editId'";

                                $result = mysqli_query($conn, $query);
  
                                $operationMode = "update";
                              }

                            }
                            else if(isset($_GET['delete'])){
                              $deleteId = $_GET['delete'];

                              $query  = "DELETE FROM category WHERE id='$deleteId' OR parent='$deleteId'";
                              $result = mysqli_query($conn, $query);

                              $operationMode = "delete";

                            }

                            if($operationMode!=false){
                              if($result){
                                  if($operationMode=="add"){
                                    $_SESSION['toastr']['message']    = array("Category added successfully!");
                                    $_SESSION['toastr']['alertType']  = "success";
                                  }
                                  else if($operationMode=="delete"){
                                    $_SESSION['toastr']['message']    = array("Category deleted successfully!");
                                    $_SESSION['toastr']['alertType']  = "success";
                                  }
                                  else if($operationMode=="update"){
                                    if(mysqli_affected_rows($conn)==0){
                                      $_SESSION['toastr']['message']    = array("No changes!");
                                      $_SESSION['toastr']['alertType']  = "info";
                                    }
                                    else{
                                      $_SESSION['toastr']['message']    = array("Category updated successfully!");
                                      $_SESSION['toastr']['alertType']  = "success";
                                    }
                                  }
                                  header("Location: category.php");
                                  exit();
                              }
                              else{
                                die("<br><b>Error: </b>".mysqli_error($conn));
                              }
                            }
                            
                        ?>

                    </div>
                </div>
                <!-- /.right col -->
            </div>
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <!-- Footer -->
  <?php include 'includes/footer.php'; ?>
  <!-- /.footer -->


<!-- Bottom elements (Scripts, Controlers) -->
  <?php include 'includes/bottom.php'; ?>
<!-- /.Bottom -->

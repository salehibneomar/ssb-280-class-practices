<?php include 'includes/header.php'; ?>

    <!-- :::::::::: Page Banner Section Start :::::::: -->
    <section class="sub-page-section">

    </section>
    <!-- ::::::::::: Page Banner Section End ::::::::: -->

    <!-- :::::::::: Blog With Right Sidebar Start :::::::: -->
    <section>
        <div class="container">
            <div class="row">
                <!-- Blog Posts Start -->
                <div class="col-md-8">

                <?php

                    if(isset($_POST['searchKey'])){
                        $searchKey = strtolower(mysqli_real_escape_string($conn, trim($_POST['searchKey'])));

                        if(empty($searchKey)){
                            header("Location: index.php");
                            exit();
                        }
                        
                        $searchKeyExploded = explode(" ", strtolower($searchKey));
                        $searchKeyModified = trim(str_replace(str_split(",-._+*&()!~`$%^<>?;:'|/\\=") ," ", $searchKey));

                        $searchKeyPrepare  = "p.title LIKE '%".implode("%' OR p.title LIKE '%",$searchKeyExploded)."%' OR p.description LIKE '%".implode("%' OR p.description LIKE '%",$searchKeyExploded)."%' OR p.tags LIKE '%".implode("%' OR p.tags LIKE '%",$searchKeyExploded)."%' OR c.name LIKE '%".implode("%' OR c.name LIKE '%",$searchKeyExploded)."%' OR u.name LIKE '%".implode("%' OR u.name LIKE '%",$searchKeyExploded)."%'";

                        $searchQuery = "SELECT p.p_id, p.title, SUBSTRING(p.description, 1, 200) AS description, p.image  ,p.dateTimePosted, p.categoryId, p.authorId, c.name AS 'searchCategoryName', u.name AS 'searchAuthorName' FROM post p, category c, user u WHERE p.status = 1 AND p.categoryId=c.id AND p.authorId=u.id AND ( ".$searchKeyPrepare." ) ORDER BY p.p_id DESC";

                    
                        $postSearchResult      = mysqli_query($conn, $searchQuery);
                        $postSearchResultCount = mysqli_num_rows($postSearchResult);

                    }
                    else{
                        header("Location: index.php");
                        exit();
                    }

                ?>

                <?php if($postSearchResultCount==0){ ?>
                    <div class="alert alert-info rounded-0 border-info">
                       <b>No records found!</b>
                    </div>
                    
                <?php } else{ ?>
                    <div class="alert alert-success rounded-0 border-success">
                      <span class="badge badge-success"><?=$postSearchResultCount;?></span><?php if($postSearchResultCount==1){ echo ' record '; }else { echo ' records '; } ?> found for search key <b><?=$searchKey;?></b>
                    </div>
                <?php

                while($row = mysqli_fetch_assoc($postSearchResult)){
                    extract($row);

                    $dateTimePosted = explode(" ",$dateTimePosted);
                    $datePosted     = intval(date('d', strtotime($dateTimePosted[0]))).date(' M, y', strtotime  ($dateTimePosted[0]));
                    $timePosted     = date('h:i a', strtotime($dateTimePosted[1]));
                
                ?>

                    <!-- Single Item Blog Post Start -->
                    <div class="blog-post">
                        <!-- Blog Banner Image -->
                        <div class="blog-banner">
                            <a href="single-post.php?post_id=<?=$p_id;?>">
                                <img src="admin/images/posts/<?=$image;?>" >
                                <!-- Post Category Names -->
                                <div class="blog-category-name">
                                    <h6><?=$searchCategoryName;?></h6>
                                </div>
                            </a>
                        </div>
                        <!-- Blog Title and Description -->
                        <div class="blog-description">
                            <a href="single-post.php?post_id=<?=$p_id;?>">
                                <h3 class="post-title">
                                    <?php 

                                    $titleArray = explode(" ", $title);

                                        foreach($titleArray as $word){

                                            $token = strtolower(trim(str_replace(str_split(",-._+*&()!~`$%^<>?;:'|/\\=") ," ", $word)));

                                            if(in_array($token, $searchKeyExploded) || in_array($word, $searchKeyExploded) || $token==$searchKeyModified 
                                            || is_int(strpos($token, $searchKeyModified))){

                                                $word = '<span class="highlight">'.$word.'</span>';
                                            }

                                            echo " ".$word;
                                        }
                                    ?>
                                </h3>
                            </a>
                            <p>
                                <?php 
                            
                                $descriptionArray = explode(" ", $description);

                                    foreach($descriptionArray as $word){

                                        $token = strtolower(trim(str_replace(str_split(",-._+*&()!~`$%^<>?;:'|/\\=") ," ", $word)));

                                        if(in_array($token, $searchKeyExploded) || in_array($word, $searchKeyExploded) || $token==$searchKeyModified 
                                        || is_int(strpos($token, $searchKeyModified))){

                                            $word = '<span class="highlight">'.$word.'</span>';
                                        }

                                        echo " ".$word;
                                    }
                                    echo '...';
                                ?>
                                
                            </p>
                            <!-- Blog Info, Date and Author -->
                            <div class="row">
                                <div class="col-md-8">
                                    <div class="blog-info">
                                        <ul>
                                            <li><i class="fa fa-calendar"></i>&ensp;<?= $datePosted;?></li>
                                            <li><i class="fa fa-clock-o"></i>&ensp;<?=$timePosted;?></li>
                                            <li><i class="fa fa-user"></i>&ensp;<?=$searchAuthorName;?></li>
                                            <!--<li><i class="fa fa-heart"></i>(50)</li>-->
                                        </ul>
                                    </div>
                                </div>

                                <div class="col-md-4 read-more-btn">
                                    <a href="single-post.php?post_id=<?=$p_id;?>" class="btn-main">Read More <i class="fa fa-angle-double-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Single Item Blog Post End -->
                <?php } ?>

                    <!-- Blog Paginetion Design Start -->
                    <?php include 'includes/pagination.php'; ?>
                    <!-- Blog Paginetion Design End -->  
                    
                <?php }  ?> 

                </div>



                <!-- Blog Right Sidebar -->
                <?php include 'includes/aside.php'; ?>
                <!-- Right Sidebar End -->

            </div>
        </div>
    </section>
    <!-- ::::::::::: Blog With Right Sidebar End ::::::::: -->
    
<?php include 'includes/footer.php'; ?>

<?php include 'includes/bottom.php'; ?>



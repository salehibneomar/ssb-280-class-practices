<?php include 'includes/header.php'; ?>

<?php
    if(isset($_GET['post_id'])){
        $postId = mysqli_real_escape_string($conn, trim($_GET['post_id']));

        if(empty($postId)){
            header("Location: index.php");
            exit();
        }

        $singlePostQuery = "SELECT p.*, c.name AS 'singlePostCategoryName', u.name AS 'singlePostAuthorName' FROM post p, category c, user u WHERE p.status = 1 AND p.categoryId=c.id AND p.authorId=u.id AND p.p_id='$postId' ";

        $singlePostResult = mysqli_query($conn, $singlePostQuery);

        $data = mysqli_fetch_assoc($singlePostResult);

        if(is_null($data)){
            header("Location: index.php");
            exit();
        }

        extract($data);

        $dateTimePosted = explode(" ",$dateTimePosted);

        $datePosted = intval(date('d', strtotime($dateTimePosted[0]))).date(' M, Y', strtotime($dateTimePosted[0]));
        $timePosted = date('h:i:s a', strtotime($dateTimePosted[1]));

    }
    else{
        header("Location: index.php");
    }
?>
    <!-- :::::::::: Page Banner Section Start :::::::: -->
    <section class="sub-page-section">

    </section>
    <!-- ::::::::::: Page Banner Section End ::::::::: -->



    <!-- :::::::::: Blog With Right Sidebar Start :::::::: -->
    <section>
        <div class="container">
            <div class="row">
                <!-- Blog Single Posts -->
                <div class="col-md-8">

                <div class="blog-single">
                        <!-- Blog Title -->
                        <a href="#">
                            <h3 class="post-title"><?=$title;?></h3>
                        </a>

                        <!-- Blog Categories -->
                        <div class="single-categories mb-5">
                            <span><?=$singlePostCategoryName;?></span>
                        </div>

                        <!-- Blog Info, Date and Author -->
                        <div class="row mb-5 w-100">
                            <div class="col-md-12">
                                <div class="blog-info">
                                    <ul>
                                        <div class="row">
                                            <div class="col-lg-6 col-sm-12">
                                                <li><i class="fa fa-calendar"></i>&ensp;Date: <?=$datePosted;?></li>
                                            </div>
                                            <div class="col-lg-6 col-sm-12">
                                                <li><i class="fa fa-clock-o"></i>&ensp;Time: <?=$timePosted;?></li>
                                            </div>
                                            <div class="col-lg-12">
                                                <li><i class="fa fa-user"></i>&ensp;Posted By - <?=$singlePostAuthorName;?></li>
                                            </div>
                                        </div>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Blog Thumbnail Image Start -->
                        <div class="blog-banner">
                            <a href="#">
                                <img src="admin/images/posts/<?=$image;?>">
                            </a>
                        </div>
                        <!-- Blog Thumbnail Image End -->

                        <!-- Blog Description Start -->
                        <p>
                            <?=$description;?>
                        </p>

                        <!--<div class="blog-description-quote">
                            <p><i class="fa fa-quote-left"></i>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.<i class="fa fa-quote-right"></i></p>
                        </div>

                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est eserunt mollit anim id labor laborumlabor laborum est.
                        </p>
                         Blog Description End -->

                        <!-- Tags -->
                        <div class="single-categories">
                            <h4 class="mb-3">Tags</h4>
                            <?php 
                                $singlePostAllTags = explode(",", $tags);

                                foreach($singlePostAllTags as $tag){
                            ?>

                            <span><?=$tag;?></span>

                            <?php } ?>
                        </div>
                    </div>

                    <!-- Single Comment Section Start -->
                    <div class="single-comments">
                        <!-- Comment Heading Start -->
                        <div class="row">
                            <div class="col-md-12">
                                <h4>All Latest Comments (3)</h4>
                                <div class="title-border"></div>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit</p>
                            </div>
                        </div>
                        <!-- Comment Heading End -->

                        <!-- Single Comment Post Start -->
                        <div class="row each-comments">
                            <div class="col-md-2">
                                <!-- Commented Person Thumbnail -->
                                <div class="comments-person">
                                    <img src="assets/images/corporate-team/team-1.jpg">
                                </div>
                            </div>

                            <div class="col-md-10 no-padding">
                                <!-- Comment Box Start -->
                                <div class="comment-box">
                                    <div class="comment-box-header">
                                        <ul>
                                            <li class="post-by-name">Someone Special</li>
                                            <li class="post-by-hour">20 Hours Ago</li>
                                        </ul>
                                    </div>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                                </div>
                                <!-- Comment Box End -->
                            </div>
                        </div>
                        <!-- Single Comment Post End -->


                        <!-- Comment Reply Post Start -->
                        <div class="row each-comments">
                            <div class="col-md-2 offset-md-2">
                                <!-- Commented Person Thumbnail -->
                                <div class="comments-person">
                                    <img src="assets/images/corporate-team/team-2.jpg">
                                </div>
                            </div>

                            <div class="col-md-8 no-padding">
                                <!-- Comment Box Start -->
                                <div class="comment-box">
                                    <div class="comment-box-header">
                                        <ul>
                                            <li class="post-by-name">Someone Special</li>
                                            <li class="post-by-hour">20 Hours Ago</li>
                                        </ul>
                                    </div>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                                </div>
                                <!-- Comment Box Start -->
                            </div>
                        </div>
                        <!-- Comment Reply Post End -->

                        <!-- Single Comment Post Start -->
                        <div class="row each-comments">
                            <div class="col-md-2">
                                <!-- Commented Person Thumbnail -->
                                <div class="comments-person">
                                    <img src="assets/images/corporate-team/team-1.jpg">
                                </div>
                            </div>

                            <div class="col-md-10 no-padding">
                                <!-- Comment Box Start -->
                                <div class="comment-box">
                                    <div class="comment-box-header">
                                        <ul>
                                            <li class="post-by-name">Someone Special</li>
                                            <li class="post-by-hour">20 Hours Ago</li>
                                        </ul>
                                    </div>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                                </div>
                                <!-- Comment Box Start -->
                            </div>
                        </div>
                        <!-- Single Comment Post End -->
                    </div>
                    <!-- Single Comment Section End -->


                    <!-- Post New Comment Section Start -->
                    <div class="post-comments">
                        <h4>Post Your Comments</h4>
                        <div class="title-border"></div>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit</p>
                        <!-- Form Start -->
                        <form action="" method="" class="contact-form">
                            <!-- Left Side Start -->
                            <div class="row">
                                <div class="col-md-6">
                                    <!-- First Name Input Field -->
                                    <div class="form-group">
                                        <input type="text" name="user-name" placeholder="Your Name" class="form-input" autocomplete="off" required="required">
                                        <i class="fa fa-user-o"></i>
                                    </div>
                                </div>
                                <!-- Email Address Input Field -->
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <input type="email" name="email" placeholder="Email Address" class="form-input" autocomplete="off" required="required">
                                        <i class="fa fa-envelope-o"></i>
                                    </div>
                                </div>
                            </div>
                            <!-- Left Side End -->

                            <!-- Right Side Start -->
                            <div class="row">
                                <div class="col-md-12">
                                    <!-- Subject Input Field -->
                                    <div class="form-group">
                                        <input type="text" name="subject" placeholder="Subject" class="form-input" autocomplete="off" required="required">
                                        <i class="fa fa-diamond"></i>
                                    </div>
                                    <!-- Comments Textarea Field -->
                                    <div class="form-group">
                                        <textarea name="comments" class="form-input" placeholder="Your Comments Here..."></textarea>
                                        <i class="fa fa-pencil-square-o"></i>
                                    </div>
                                    <!-- Post Comment Button -->
                                    <button type="submit" class="btn-main"><i class="fa fa-paper-plane-o"></i> Post Your Comments</button>
                                </div>
                            </div>
                            <!-- Right Side End -->
                        </form>
                        <!-- Form End -->
                    </div>
                    <!-- Post New Comment Section End -->              
                </div>




                <!-- Blog Right Sidebar -->
                <?php include 'includes/aside.php'; ?>
                <!-- Right Sidebar End -->
            </div>
        </div>
    </section>
    <!-- ::::::::::: Blog With Right Sidebar End ::::::::: -->
    


<?php include 'includes/footer.php'; ?>

<?php include 'includes/bottom.php'; ?>

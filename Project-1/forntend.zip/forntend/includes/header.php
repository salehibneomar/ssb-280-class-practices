<?php
    require 'config/db.php';
    ob_start();
    date_default_timezone_set('Asia/Dhaka');
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required Meta Tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Website Description -->
    <meta name="description" content="Blue Chip: Corporate Multi Purpose Business Template" />
    <meta name="author" content="Blue Chip" />

    <!--  Favicons / Title Bar Icon  -->
    <link rel="shortcut icon" href="assets/images/favicon/favicon.png" />
    <link rel="apple-touch-icon-precomposed" href="assets/images/favicon/favicon.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/images/favicon/favicon.png" />
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/images/favicon/favicon.png" />

  <?php
      $pageURI   = $_SERVER['REQUEST_URI'];
      $pageTitle = explode("/", $pageURI);
      $pageTitle = end($pageTitle);

      $pageTitle = substr($pageTitle, 0, strpos($pageTitle, "."));
     
      $pageTitle = ucwords(str_replace("-", " ", $pageTitle));

      if($pageTitle=="Index"){
        $pageTitle = "Home";
      }
  ?>
    <title>SSB-280 | <?=$pageTitle;?></title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" type="text/css" href="assets/bootstrap/css/bootstrap.min.css">

    <!-- Font Awesome CSS -->
    <link rel="stylesheet" type="text/css" href="assets/css/font-awesome.min.css">

    <!-- Flat Icon CSS -->
    <link rel="stylesheet" type="text/css" href="assets/css/flaticon.css">

    <!-- Animate CSS -->
    <link rel="stylesheet" type="text/css" href="assets/css/animate.min.css">

    <!-- Owl Carousel CSS -->
    <link rel="stylesheet" type="text/css" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/owl.theme.default.min.css">

    <!-- Fency Box CSS -->
    <link rel="stylesheet" type="text/css" href="assets/css/jquery.fancybox.min.css">

    <!-- Theme Main Style CSS -->
    <link rel="stylesheet" type="text/css" href="assets/css/style.css">

    <!-- Responsive CSS -->
    <link rel="stylesheet" type="text/css" href="assets/css/responsive.css">
  </head>

  <body>
    <!-- :::::::::: Header Section Start :::::::: -->
    <header class="bg-light">
        <div class="container col-lg-11 col-md-10">
            <div class="row">
                <div class="col-md-12">
                    <nav class="navbar navbar-expand-lg  bg-transparent py-4" >
                        <a class="navbar-brand" href="index.php"> <b>SSB-280</b> </a>
                        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                          <span class="navbar-toggler-icon"></span>
                        </button>
                      
                        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                          <ul class="navbar-nav ml-auto">

                            <!-- <li class="nav-item dropdown bs-dropdown">
                              <a class="nav-link dropdown-toggle dropdown-toggle-text" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                Categories
                              </a>
                              <div class="dropdown-menu bs-dropdown-menu" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item dropdown-text" href="#">Action</a>
                              </div>
                            </li> -->
                          <?php 
                              $query  = "SELECT name AS 'navCategoryName', id AS 'navCategoryId' FROM category WHERE status = 1 ORDER BY name ASC";
                              $result = mysqli_query($conn, $query);

                              while($row = mysqli_fetch_assoc($result)){
                                extract($row);
                          ?>

                            <li class="nav-item">
                                <a class="nav-link" href="post-by-category.php?category=<?=$navCategoryName;?>"><?=$navCategoryName;?></a>
                            </li>

                          <?php } ?> 

                          </ul>
                        </div>

                      </nav>
                </div>
            </div>
        </div>
    </header>

    <!-- ::::::::::: Header Section End ::::::::: -->